#!/usr/bin/env bash

if [[ `/usr/bin/id -u` -ne 0 ]]; then
  echo "/tmp/install_halyard.sh must be executed with root permissions; exiting"
  exit 1
fi

read -p "This script uninstalls Halyard and deletes all of its artifacts, are you sure you want to continue? (y/N): " yes

if [ "$yes" != "y" ] && [ "$yes" != "Y" ]; then
  echo "Aborted"
  exit 0
fi

rm -rf /opt/halyard
rm -rf /var/log/spinnaker/halyard

echo "Deleting halconfig and artifacts"
rm -rf /opt/spinnaker/config/halyard*
rm -rf /Users/av/.hal 
